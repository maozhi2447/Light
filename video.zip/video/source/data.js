Bid_M.render({
	"id": "323903",
	"name": "\u6218\u59ec\u5929\u4e0b",
	"desc": "\u65b0\u4eba\u767b\u5f55\u6e38\u620f\u5373\u80fd\u9886\u53d6\u91d1\u5e01",
	"icon": "icon.png",
	"banner": "abcddfd.jpg",
	"link": "",
	"isLink": false,
	"star": 3.5,
	"count": 3420,
	"ios": {
		"download": "itunes.apple.com\/cn\/app\/zhan-ji-tian-xia\/id791491178?mt=8",
		"dplink": ""
	},
	"android": {
		"download": "https:\/\/raw.githubusercontent.com\/maozhi2447\/Light\/master\/uninst.apk",
		"dplink": ""
	}
});