Bid_M().init({
	"id": "323903",
	"name": "\u6218\u59ec\u5929\u4e0b",
	"desc": "\u65b0\u4eba\u767b\u5f55\u6e38\u620f\u5373\u80fd\u9886\u53d6\u91d1\u5e01",
	"icon": "icon.png",
	"banner": "abcddfd.jpg",
	"star": 3.5,
	"count": 3420,
	"url": "https:\/\/itunes.apple.com\/cn\/app\/zhan-ji-tian-xia\/id791491178?mt=8",
	"isApp": true
})