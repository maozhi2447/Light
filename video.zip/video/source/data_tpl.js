Bid_M.render({
	"id": "323903",
	"name": "{PRODUCT_NAME}",
	"desc": "{PRODUCT_SUMMARY}",
	"icon": "{PRODUCT_ICON_PATH}",
	"banner": "{BANNER_PATH}",
	"link": "{WEB_URL}",
	"isLink": {IS_OPEN_URL},
	"star": {RATE},
	"count": {DOWNLOADS},
	"ios": {
		"download": "{ITUNES_URL}",
		"dplink": "{IOS_DEEP_URL}"
	},
	"android": {
		"download": "{APK_URL}",
		"dplink": "{ANDROID_DEEP_URL}"
	}
});