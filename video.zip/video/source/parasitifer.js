Bid_M.parasitifer({
	'status': 'download'    // download | dplink
});