(function (win, doc) {
	var old = win.Bid_M;

	function Bid_M(cfg) {
		var instance = this;
		function instancOf(instance, factory) {
			return instance && instance.hasOwnProperty &&  (instance instanceof factory);
		}

		if (!instancOf(instance, Bid_M)) {
			instance = new Bid_M(cfg);
		}
		instance.cfg = cfg || {};
		return instance;
	}

	function $(id) {
		return doc.getElementById(id);
	}

	var fn = Bid_M.prototype;

	fn.init = function (data) {
		var that = this;
		that.data = data;
		that.run();
		return that;
	}
	fn.batchHtml = function(tag, count, klazz) {
		var i, prop, html = '';
		for (i = 0; i < count; i++) {
			html += '<' + tag + ' class=' + klazz + '></' + tag + '>';
		}
		return html
	}
	fn.formatCount = function(count, separator, size) {
		var pos, res = [];
		if (count !== +count) {return '0';}
		separator = separator || ',';
		size = size || 3;
		count = String(Math.round(count));
		pos = count.length;
		while(pos > 0) {
			res.unshift(count.substring(pos - size, pos));
			pos -= size;
		}
		return res.join(separator) || '0';
	}
	fn.getStarHtml = function(star) {
		var i = 0;
		var amout = 5;
		var ns = String(star || 0).split('.');
		var full = ns.shift() || 0;
		var half = ns.shift() ? 1 : 0;
		var empty = amout - full - half;
		return this.batchHtml('i', full, 'icon-star-full') + this.batchHtml('i', half, 'icon-star-half') + this.batchHtml('i', empty, 'icon-star-empty');
	}
	fn.run = function() {
		var data = this.data;
		var dir = this.cfg.dir || 'source/';
		$("banner").style.backgroundImage = "url(" + dir + data.banner + ")";
		$("icon").setAttribute("src", dir + data.icon);
		$("title").innerHTML = data.name;
		$("star").innerHTML = this.getStarHtml(data.star);
		$("count").innerHTML = this.formatCount(data.count);
		$("info").innerHTML = data.desc;
		$("anchor").href = (data.isApp ? "download://" : '') + data.url.replace(/^(https?:)?\/\//, '');
		$("anchor").innerHTML = data.isApp ? "立即下载" : "打开网页";
	}
	fn.noConflict = function() {
		if ( window.Bid_M === Bid_M ) {
			window.Bid_M = old;
		}
		return Bid_M;
	}
	win.Bid_M = Bid_M;
})(window, document)
