(function (win, doc) {
	var old = win.Bid_M;

	function Bid_M_Fac(cfg) {
		var instance = this;
		function instancOf(instance, factory) {
			return instance && instance.hasOwnProperty &&  (instance instanceof factory);
		}

		if (!instancOf(instance, Bid_M_Fac)) {
			instance = new Bid_M_Fac(cfg);
		}
		instance.cfg = cfg || {};
		return instance;
	}

	function $(id) {
		return doc.getElementById(id);
	}

	var fn = Bid_M_Fac.prototype;

	// 批量html
	fn.batchHtml = function(tag, count, klazz) {
		var i, prop, html = '';
		for (i = 0; i < count; i++) {
			html += '<' + tag + ' class=' + klazz + '></' + tag + '>';
		}
		return html
	}
	// 格式化下载人数
	fn.formatCount = function(count, separator, size) {
		var pos, res = [];
		if (count !== +count) {return '0';}
		separator = separator || ',';
		size = size || 3;
		count = String(Math.round(count));
		pos = count.length;
		while(pos > 0) {
			res.unshift(count.substring(pos - size, pos));
			pos -= size;
		}
		return res.join(separator) || '0';
	}
	// 获取星级html
	fn.getStarHtml = function(star) {
		var i = 0;
		var amout = 5;
		var ns = String(star || 0).split('.');
		var full = ns.shift() || 0;
		var half = ns.shift() ? 1 : 0;
		var empty = amout - full - half;
		return this.batchHtml('i', full, 'icon-star-full') + this.batchHtml('i', half, 'icon-star-half') + this.batchHtml('i', empty, 'icon-star-empty');
	}
	// 绘制
	fn.draw = function() {
		var data = this.data;
		var osData = this.osData;
		$("banner").style.backgroundImage = "url(" + Bid_M_source_dir + data.banner + ")";
		$("icon").setAttribute("src", Bid_M_source_dir + data.icon);
		$("title").innerHTML = data.name;
		$("info").innerHTML = data.desc;
		$("star").innerHTML = this.getStarHtml(data.star);
		$("count").innerHTML = this.formatCount(data.count);
		if (data.isLink) {
			$("anchor").href = data.link.indexOf('http') === 0 ? data.link : 'http://' + data.link;
			$("anchor").innerHTML = "打开网页";
		} else if (osData) {
			$("anchor").href = 'download://' + osData.download;
			$("anchor").innerHTML = "立即下载";
		}
	}
	// 数据传入接口
	fn.render = function (data) {
		var that = this;
		that.data = data;
		var osData;
		switch(Bid_M_os) {
			case 'ios':
				osData = data.ios;
			break;
			case 'android':
				osData = data.android;
			break;
		}
		that.osData = osData;
		that.draw();
		return that;
	}
	// 平台回调函数
	fn.parasitifer = function(param) {
		this.param = param;
		var os = param.os;
		var status = param.status;
		var data = this.data;
		var osData = this.osData;

		// 类型为链接时不做处理
		if (!data.isLink) {
			if (osData) {
				switch (status) {
					case 'dplink':
						$("anchor").href = 'dplink://' + osData.dplink;
						$("anchor").innerHTML = "启动";
					break;
					// 默认是download，不作处理
					// default:
					// case 'download':
					// 	$("anchor").href = 'download://' + osData.download;
					// 	$("anchor").innerHTML = "立即下载";
					// break;
				}
			}
		}
	}
	fn.noConflict = function() {
		if ( win.Bid_M === this ) {
			win.Bid_M = old;
		}
		return this;
	}
	win.Bid_M = Bid_M_Fac();
})(window, document)
